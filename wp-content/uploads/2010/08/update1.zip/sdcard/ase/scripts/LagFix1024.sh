clear
echo clear>>/sdcard/ase/resources/temp.sh
echo echo "Creating 1GB file to store data inside. This could take a long time...">>/sdcard/ase/resources/temp.sh
echo busybox dd if=/dev/zero of=/data/linux.ex2 bs=1024 count=1048576 seek=1000>>/sdcard/ase/resources/temp.sh
echo echo "Creating loopback, you may see an error that it already exists. Ignore that error.">>/sdcard/ase/resources/temp.sh
echo busybox mknod /dev/loop0 b 7 0 >>/sdcard/ase/resources/temp.sh
echo echo "Linking loopback to the 1GB file store">>/sdcard/ase/resources/temp.sh
echo busybox losetup /dev/loop0 /data/linux.ex2>>/sdcard/ase/resources/temp.sh
echo echo "Creating the EXT2 filesystem">>/sdcard/ase/resources/temp.sh
echo busybox mkfs.ext2 -b 4096 /dev/loop0>>/sdcard/ase/resources/temp.sh
echo echo "Creating a mountpoint for files, you may see an error that it already exists. Ignore that error.">>/sdcard/ase/resources/temp.sh
echo mkdir /data/ext2data>>/sdcard/ase/resources/temp.sh
echo echo "Mounting device">>/sdcard/ase/resources/temp.sh
echo mount -t ext2 -o noatime,nodiratime,errors=continue /dev/loop0 /data/ext2data>>/sdcard/ase/resources/temp.sh
echo echo "Copying data across">>/sdcard/ase/resources/temp.sh
echo busybox cp -rp /data/data /data/ext2data/>>/sdcard/ase/resources/temp.sh
echo busybox cp -rp /data/system /data/ext2data/>>/sdcard/ase/resources/temp.sh
echo busybox cp -rp /data/dalvik-cache /data/ext2data/>>/sdcard/ase/resources/temp.sh
echo echo "Clearing out any old backups, ignore any errors">>/sdcard/ase/resources/temp.sh
echo busybox rm -rf /data/data.bak>>/sdcard/ase/resources/temp.sh
echo busybox rm -rf /data/system.bak>>/sdcard/ase/resources/temp.sh
echo busybox rm -rf /data/dalvik-cache.bak>>/sdcard/ase/resources/temp.sh
echo echo "Backing up old data">>/sdcard/ase/resources/temp.sh
echo busybox mv /data/data /data/data.bak>>/sdcard/ase/resources/temp.sh
echo busybox mv /data/system /data/system.bak>>/sdcard/ase/resources/temp.sh
echo busybox mv /data/dalvik-cache /data/dalvik-cache.bak>>/sdcard/ase/resources/temp.sh
echo echo "Linking to fast ext2">>/sdcard/ase/resources/temp.sh
echo busybox ln -s /data/ext2data/data /data/data>>/sdcard/ase/resources/temp.sh
echo busybox ln -s /data/ext2data/system /data/system>>/sdcard/ase/resources/temp.sh
echo busybox ln -s /data/ext2data/dalvik-cache /data/dalvik-cache>>/sdcard/ase/resources/temp.sh
echo echo "Now setting up reboot support">>/sdcard/ase/resources/temp.sh
echo echo "Moving boot animation">>/sdcard/ase/resources/temp.sh
echo busybox mv /system/bin/playlogos1 /system/bin/playlogosnow>>/sdcard/ase/resources/temp.sh
echo echo "Copying over init scripts">>/sdcard/ase/resources/temp.sh
echo busybox cp /sdcard/ase/resources/playlogos1 /system/bin/playlogos1>>/sdcard/ase/resources/temp.sh
echo busybox cp /sdcard/ase/resources/userinit.sh /system/bin/userinit.sh>>/sdcard/ase/resources/temp.sh
echo echo "Setting up permissions">>/sdcard/ase/resources/temp.sh
echo busybox chmod 755 /system/bin/playlogos1>>/sdcard/ase/resources/temp.sh
echo busybox chmod 755 /system/bin/userinit.sh>>/sdcard/ase/resources/temp.sh
echo echo "All Complete!">>/sdcard/ase/resources/temp.sh
echo busybox rm /sdcard/ase/resources/temp.sh>>/sdcard/ase/resources/temp.sh
su</sdcard/ase/resources/temp.sh