clear
echo echo "Removing symlinks">>/sdcard/ase/resources/temp.sh
echo busybox rm -r /data/data>>/sdcard/ase/resources/temp.sh
echo busybox rm -r /data/system>>/sdcard/ase/resources/temp.sh
echo busybox rm -r /data/dalvik-cache>>/sdcard/ase/resources/temp.sh
echo echo "Copying data back from EXT2 to RFS">>/sdcard/ase/resources/temp.sh
echo busybox cp -rp /data/ext2data/data /data/>>/sdcard/ase/resources/temp.sh
echo busybox cp -rp /data/ext2data/system /data/>>/sdcard/ase/resources/temp.sh
echo busybox cp -rp /data/ext2data/dalvik-cache /data/>>/sdcard/ase/resources/temp.sh
echo echo "Removing datafile">>/sdcard/ase/resources/temp.sh
echo busybox rm -r /data/ext2data>>/sdcard/ase/resources/temp.sh
echo busybox rm /data/linux.ex2>>/sdcard/ase/resources/temp.sh
echo echo "Removing auto boot support">>/sdcard/ase/resources/temp.sh
echo busybox mv /system/bin/playlogosnow /system/bin/playlogos1>>/sdcard/ase/resources/temp.sh
echo echo "All done! Rebooting device so that the EXT2 Loopback device is freed.">>/sdcard/ase/resources/temp.sh
echo busybox rm /sdcard/ase/resources/temp.sh>>/sdcard/ase/resources/temp.sh
echo reboot>>/sdcard/ase/resources/temp.sh
su</sdcard/ase/resources/temp.sh